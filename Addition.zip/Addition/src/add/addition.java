package add;

class Addition {
	public static void main(String[] args) {
		int var1;
		float var2;
		int res;
		
		var1 = 10;
		var2 = 105345;
		
		res = (int)(var1+var2);
		System.out.println(res);
		
	}
}